#! /bin/bash
# v1 : FAT16 and FAT32, based on Trammel version
# v2 : exFAT supported. arm.indiana@gmail.com
# v3 : Osx and Linux auto detect device
#
# patch the SD/CF card bootsector to make it bootable on Canon DSLR
# See http://chdk.setepontos.com/index.php/topic,4214.0.html
#     http://en.wikipedia.org/wiki/File_Allocation_Table#Boot_Sector

# usage: make_bootable.sh (card needs to be formatted on camera or have volume name: EOS_DIGITAL)
# exfat_sum.c must bu compiled first

# Check if we are root or not. If yes, then terminate the script.
if [[ $UID != 0 ]]; then
  echo -e "\nThis script must be run as root. Exiting.\n"
  exit 1
fi

dump_file=exfat_dump.bin

echo -e "\n"
read -r -p "Insert the card mount location (full path, with start & end slashes): " mountpoint

awk_input=$(echo $mountpoint | sed -e 's/\//\\\//g' -e 's/\(.*\)\\\//\1/')
mountdevice=$(mount | awk /$awk_input/{print} | awk '{print $1}') #prints the mount location of a SD card

echo -e "\nInput device is $mountdevice (mount point: $mountpoint)"

read -r -p "Is that correct? [y/N] " response
if [[ $(echo $response | sed 's/ //g') =~ ^([yY][eE][sS]|[yY])$ ]]; then

  # read the boot sector to determine the filesystem version
  EXFAT=`dd if=$mountdevice bs=1 skip=3 count=8 2>/dev/null`
  DEV32=`dd if=$mountdevice bs=1 skip=82 count=8 2>/dev/null`
  DEV16=`dd if=$mountdevice bs=1 skip=54 count=8 2>/dev/null`
  if [ "$DEV16" != 'FAT16   ' -a "$DEV32" != 'FAT32   ' -a "$EXFAT" != 'EXFAT   ' ]; then
    echo "Error: $mountdevice is not a FAT16, FAT32 of EXFAT device"
    echo "Format your card in camera before using this script"
    echo debug $mountdevice $DEV16 $DEV32 $EXFAT
    exit
  fi
  if [ "$DEV16" = 'FAT16   ' ]; then
    offset1=43
    offset2=64
    FS='FAT16'
  elif [ "$DEV32" = 'FAT32   ' ]; then
    offset1=71
    offset2=92
    FS='FAT32'
  elif [ "$EXFAT" = 'EXFAT   ' ]; then
    offset1=130
    offset2=122
    FS='EXFAT'
  else
    echo "Error: "$mountdevice" is not a FAT16, FAT32 or EXFAT (FAT64) device"
    exit
  fi
  echo "Applying "$FS" parameters on "$mountdevice" device:"
  echo "Writing EOS_DEVELOP at offset" $offset1 "(Volume label)"
  echo EOS_DEVELOP | dd of="$mountdevice" bs=1 seek=$offset1 count=11
  echo "Writing BOOTDISK at offset" $offset2 "(Boot code)"
  echo BOOTDISK | dd of="$mountdevice" bs=1 seek=$offset2 count=8
  if [ "$FS" = 'EXFAT' ]; then
  echo "EXFAT: Tested only on 8GB card, correct BACKUP OFFSET may be different for bigger cards. Post feedback to www.magiclantern.fm/forum/"
  # write them also in backup VBR, at sector 13
  echo EOS_DEVELOP | dd of="$mountdevice" bs=1 seek=$(($offset1+512*12)) count=11 2>/dev/null
  echo BOOTDISK | dd of="$mountdevice" bs=1 seek=$(($offset2+512*12)) count=8 2>/dev/null
  dd if=$mountdevice of="$dump_file" bs=1 skip=0 count=6144 2>/dev/null
  echo -n 'Recompute checksum. '
  exfat_sum "$dump_file"
  # write VBR checksum (from sector 0 to sector 10) at offset 5632 (sector 11) and offset 11776 (sector 23, for backup VBR)
  # checksum sector is stored in $dump_file at offset 5632
  dd of="$mountdevice" if="$dump_file" bs=1 seek=5632 skip=5632 count=512 2>/dev/null
  dd of="$mountdevice" if="$dump_file" bs=1 seek=11776 skip=5632 count=512 2>/dev/null
  #dd if=$mountdevice of=verif_dump.bin bs=1 skip=0 count=12288 2>/dev/null
  rm -f "$dump_file"
  fi
  echo -e "\nDone. Copy Magic Lantern files into the SD card (if not done) and you are good to go.\nIf you encounter problems, post to www.magiclantern.fm/forum/\n"
else
exit 1
fi
